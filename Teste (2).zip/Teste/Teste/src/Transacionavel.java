interface Transacionavel {
    void realizarTransferencia();
    void cancelarTransferencia();
}